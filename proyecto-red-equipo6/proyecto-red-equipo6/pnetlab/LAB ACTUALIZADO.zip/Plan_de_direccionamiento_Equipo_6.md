# Plan de direccionamiento — Equipo 6

Base asignada en P1.docx: IPv4 `172.26.0.0/15` e IPv6 `2001:25:26::/48`. La primera subred IPv6 se asigna a Estudiantes (1500 equipos), y las demás siguen el tamaño requerido en IPv4. **La tabla IPv6 es una propuesta de diseño; todavía no acredita que IPv6 esté configurado en PNETLab.**

| Orden | Segmento | Equipos solicitados | Red IPv4 existente | Prefijo IPv6 propuesto | Puerta de enlace IPv6 prevista |
|---|---|---:|---|---|---|
| 1 | VLAN 20 Estudiantes | 1500 | `172.26.0.0/21` | `2001:25:26:0::/64` | `2001:25:26:0::1` reservada para redundancia |
| 2 | VLAN 10 Docentes | 164 | `172.26.8.0/24` | `2001:25:26:1::/64` | `2001:25:26:1::1` reservada para redundancia |
| 3 | VLAN 60 Académicos | 80 | `172.26.9.0/25` | `2001:25:26:2::/64` | R2 `2001:25:26:2::1` |
| 4 | VLAN 50 Finanzas | 64 | `172.26.9.128/25` | `2001:25:26:3::/64` | R2 `2001:25:26:3::1` |
| 5 | VLAN 70 Datacenter | 44 | `172.26.10.0/26` | `2001:25:26:4::/64` | R2 `2001:25:26:4::1` |
| 6 | VLAN 30 Gestión | 29 | `172.26.10.64/27` | `2001:25:26:5::/64` | `2001:25:26:5::1` reservada para redundancia |
| 7 | VLAN 40 Voz | 16 | `172.26.10.96/27` | `2001:25:26:6::/64` | `2001:25:26:6::1` reservada para redundancia |
| 8 | VLAN 999 Blackhole, lado R1 | 10 | Sin interfaz IPv4 de usuarios | `2001:25:26:7::/64` reservada | Ninguna |
| 9 | VLAN 999 Blackhole, lado R2 | 10 | Sin interfaz IPv4 de usuarios | `2001:25:26:8::/64` reservada | Ninguna |

En las VLAN 10, 20, 30 y 40 se reservan `::2` para SWM1 y `::3` para SWM2 dentro del prefijo respectivo. La dirección `::1` sería virtual **solo si se configura y comprueba HSRP para IPv6**; el HSRP IPv4 existente no crea por sí solo una puerta de enlace IPv6. En las VLAN 50, 60 y 70 la dirección `::1` corresponde a la subinterfaz prevista de R2. Para el servidor del Datacenter se reserva `2001:25:26:4::10/64` como dirección fija propuesta.

| Enlace punto a punto | Red IPv4 existente | Prefijo IPv6 propuesto | Extremo A | Extremo B |
|---|---|---|---|---|
| R1-CORE — R2 | `172.26.10.160/30` | `2001:25:26:9::2/127` | R1 `2001:25:26:9::2` | R2 `2001:25:26:9::3` |
| R1-CORE — SWM1 | `172.26.10.164/30` | `2001:25:26:a::2/127` | R1 `2001:25:26:a::2` | SWM1 `2001:25:26:a::3` |
| R1-CORE — SWM2 | `172.26.10.168/30` | `2001:25:26:b::2/127` | R1 `2001:25:26:b::2` | SWM2 `2001:25:26:b::3` |
| R1-CORE — ISP | `203.0.113.0/30` | `2001:25:26:c::2/127` reservado | R1 `2001:25:26:c::2` | ISP `2001:25:26:c::3`, sujeto a compatibilidad de su imagen |

## Plan SLAAC/DHCPv6

1. En las VLAN de usuarios (10, 20, 30, 40, 50 y 60), la puerta de enlace anuncia el `/64` mediante Router Advertisements para que los equipos obtengan su dirección y ruta por SLAAC.
2. DHCPv6 **sin estado** puede entregar DNS y dominio, una vez que se disponga de un servicio DNS IPv6. No se asignan direcciones de usuario por DHCPv6 en este plan. El DNS IPv4 `8.8.8.8` que aparece en las concesiones actuales no equivale a una dirección DNS IPv6.
3. En el Datacenter, asignar direcciones fijas a servidores; reservar `2001:25:26:4::10` para el servidor actual. Los enlaces entre equipos de red usan las direcciones fijas de la tabla anterior. La VLAN 999 no anuncia prefijo ni ofrece SLAAC/DHCPv6.

## Estado y próximos pasos

- Confirmado en PNETLab: la topología nueva contiene configuración IPv4 de R1, R2 y los switches; FIN1 ya recibe DHCP IPv4 y alcanza el ISP por ping. No hay prueba aportada de IPv6 configurado o de conectividad IPv6.
- Para cumplir el entregable de direccionamiento del Sprint 1, incorporar estas tablas y el plan SLAAC/DHCPv6 a la documentación, indicando que son el **diseño propuesto**.
- Si el grupo decide desplegar IPv6 además del plan, comprobar primero que las imágenes IOL soportan las funciones necesarias; después configurar prefijos y anuncios, rutas IPv6, y verificar direcciones y pings. La imagen usada para ISP es L2 y requiere comprobación especial antes de asignarle IPv6.
- De la lista pendiente del colaborador, FIN1 con DHCP e ISP se resolvieron y probaron. Los avisos MOTD de los diez dispositivos IOS quedaron incluidos en el respaldo. Este plan aporta el direccionamiento IPv6 solicitado para el documento del equipo.
